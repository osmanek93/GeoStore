package com.mapcontrol.ui.activity;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.mapcontrol.R;
import com.mapcontrol.ui.builder.AppsTabBuilder;
import com.mapcontrol.ui.builder.WifiTabBuilder;
import com.mapcontrol.ui.theme.UiStyles;
import com.mapcontrol.util.ApkSessionInstaller;

/**
 * Geo Market: MapControl uygulamasindan ayrilmis, yalnizca iki sekmeli kucuk surum.
 * Sekmeler: Wi-Fi ve Uygulama Marketi.
 */
public class MainActivity extends AppCompatActivity {

    private static final int TAB_WIFI = 0;
    private static final int TAB_APPS = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private WifiTabBuilder wifiTabBuilder;
    private AppsTabBuilder appsTabBuilder;
    private FrameLayout contentFrame;
    private LinearLayout appsTopBarActions;
    private Button btnTabWifi;
    private Button btnTabApps;
    private ApkSessionInstaller.Listener apkSessionListener;
    private int currentTab = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        wifiTabBuilder = new WifiTabBuilder(this, msg -> { /* log kullanilmiyor */ });
        appsTabBuilder = new AppsTabBuilder(this, new AppsTabBuilder.AppsCallback() {
            @Override
            public boolean isSystemOrPrivApp(ApplicationInfo appInfo) {
                return MainActivity.this.isSystemOrPrivApp(appInfo);
            }

            @Override
            public boolean isSystemOrPrivApp(String packageName) {
                return MainActivity.this.isSystemOrPrivApp(packageName);
            }

            @Override
            public void log(String message) { /* log kullanilmiyor */ }
        });

        apkSessionListener = (status, message) -> handler.post(() -> onApkSessionStatus(status, message));
        ApkSessionInstaller.setListener(apkSessionListener);

        setContentView(buildRoot());
        switchTab(TAB_WIFI);

        ApkSessionInstaller.handleSessionResultIntent(this, getIntent());
    }

    private View buildRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_root_gradient);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        int pad = UiStyles.dimenPx(this, R.dimen.oem_card_margin);
        topBar.setPadding(pad, pad, pad, 0);

        btnTabWifi = tabButton(R.string.market_tab_wifi, TAB_WIFI);
        btnTabApps = tabButton(R.string.market_tab_apps, TAB_APPS);
        topBar.addView(btnTabWifi, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        topBar.addView(btnTabApps, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // Uygulamalar sekmesinin yenile / indirilenler / sunucu-yerel dugmeleri
        appsTopBarActions = appsTabBuilder.buildTopBarButtons(this);
        appsTopBarActions.setVisibility(View.GONE);
        topBar.addView(appsTopBarActions, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        root.addView(topBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        contentFrame = new FrameLayout(this);
        contentFrame.addView(wifiTabBuilder.getTabContent(), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        contentFrame.addView(appsTabBuilder.getTabContent(), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(contentFrame, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private Button tabButton(int textRes, int tab) {
        Button b = new Button(this);
        b.setText(textRes);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setOnClickListener(v -> switchTab(tab));
        return b;
    }

    private void switchTab(int tab) {
        if (tab == currentTab) return;
        if (currentTab == TAB_APPS) appsTabBuilder.onTabHidden();
        currentTab = tab;

        wifiTabBuilder.getTabContent().setVisibility(tab == TAB_WIFI ? View.VISIBLE : View.GONE);
        appsTabBuilder.getTabContent().setVisibility(tab == TAB_APPS ? View.VISIBLE : View.GONE);
        appsTopBarActions.setVisibility(tab == TAB_APPS ? View.VISIBLE : View.GONE);

        int active = UiStyles.color(this, R.color.textPrimary);
        int inactive = UiStyles.color(this, R.color.textSecondaryCool);
        btnTabWifi.setTextColor(tab == TAB_WIFI ? active : inactive);
        btnTabApps.setTextColor(tab == TAB_APPS ? active : inactive);

        if (tab == TAB_WIFI) {
            wifiTabBuilder.updateWifiStatus();
        } else {
            appsTabBuilder.onTabVisible();
            appsTabBuilder.loadAppsFromServer();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        ApkSessionInstaller.handleSessionResultIntent(this, intent);
    }

    private void onApkSessionStatus(int status, String message) {
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            return;
        }
        if (status == PackageInstaller.STATUS_SUCCESS) {
            Toast.makeText(this, R.string.apps_installed_success, Toast.LENGTH_SHORT).show();
            appsTabBuilder.loadAppsFromServer();
            return;
        }
        String detail = message != null && !message.isEmpty() ? message : ("status " + status);
        Toast.makeText(this, getString(R.string.apps_install_error, detail), Toast.LENGTH_LONG).show();
        appsTabBuilder.clearInstallingProgress();
    }

    private boolean isSystemOrPrivApp(ApplicationInfo appInfo) {
        try {
            if (appInfo == null) return true;
            if ("com.mapmarket".equals(appInfo.packageName)) return false;
            boolean isSystemApp = (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            boolean isUpdatedSystemApp = (appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            if (isSystemApp || isUpdatedSystemApp) return true;
            String sourceDir = appInfo.sourceDir;
            String publicSourceDir = appInfo.publicSourceDir;
            if (sourceDir != null && (sourceDir.contains("/system/priv-app/") || sourceDir.contains("/system/app/"))) {
                return true;
            }
            return publicSourceDir != null
                    && (publicSourceDir.contains("/system/priv-app/") || publicSourceDir.contains("/system/app/"));
        } catch (Exception e) {
            return true;
        }
    }

    private boolean isSystemOrPrivApp(String packageName) {
        try {
            if (packageName == null || packageName.isEmpty()) return true;
            if ("com.mapmarket".equals(packageName)) return false;
            PackageManager pm = getPackageManager();
            return isSystemOrPrivApp(pm.getApplicationInfo(packageName, 0));
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    protected void onDestroy() {
        ApkSessionInstaller.clearListener(apkSessionListener);
        super.onDestroy();
    }
}

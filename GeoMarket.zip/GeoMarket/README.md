# Geo Market

MapControl 1.3.4 uygulamasindan ayrilmis, yalnizca iki sekmeli kucuk surum:

1. **Wi-Fi** sekmesi: Wi-Fi ac/kapat, tara, aga baglan.
2. **Uygulamalar** sekmesi (uygulama marketi): listeden uygulama indir, kur, ac, kaldir.

## Market linkini degistirme

Market, bir `list.json` dosyasindan okur. Adresi iki yoldan biriyle degistir:

- `app/build.gradle` icindeki varsayilan adresi duzenle (`marketListUrl`), ya da
- `gradle.properties` dosyasina su satiri ekle: `MARKET_LIST_URL=https://siten.com/list.json`

Varsayilan adres yer tutucudur (osmanek93 kullanici adi ile ayarli). Bos ornek liste: market-list/list.json

### list.json bicimi

```json
{
  "list": [
    {
      "packageName": "com.ornek.uygulama",
      "displayName": "Ornek Uygulama",
      "version": "1.0",
      "downloadUrl": "https://siten.com/apk/ornek.apk"
    }
  ]
}
```

Istege bagli alanlar: `group`, `requires` (baska paket adlari listesi) ve ust seviyede `groups`.

## Derleme

- Yerelde: `./gradlew assembleDebug` (Android SDK ve JDK 17 gerekir).
- GitHub'da: depoya yukle, **Actions > APK derle > Run workflow**. APK "Artifacts" altinda cikar.

## Notlar

- applicationId `com.mapmarket`; MapControl ile ayni cihazda yan yana durabilir.
- Sessiz kurulum dex dosyasi (`mapcontrol-silent-installer.dex`) kaynak zip icinde yok. Kurulum
  standart PackageInstaller ile yapilir, onay penceresi cikabilir.
- Proje henuz derlenip test EDILMEDI; ilk derlemede kucuk hatalar cikabilir.
